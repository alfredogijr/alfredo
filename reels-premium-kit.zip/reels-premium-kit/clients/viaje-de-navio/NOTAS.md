# Viaje de Navio: notas do cliente

- Marca de cruzeiros do Grupo JPM (ao lado de JPM Viagens e Turista FC).
- Público dos reels: classe A. Estilo aprovado: o "premium" deste kit.
- Sediada no Rio de Janeiro, atua no Brasil e no exterior: **não** posicionar como marca carioca (cortar "mercado carioca", "mercado do Rio").
- Porta-voz: Pablo Vilaseca, sócio. Deve aparecer do começo ao fim dos reels.
- Logo oficial: `logo.jpeg` (fundo branco). Nunca recriar a logo.
- Pendências: confirmar @ do Instagram, grafia e cargos de João Paulo e Márcio, ano de criação (2009 ou 2010; usar só "2010" ligado ao projeto com a MSC).
- Reels já entregues: lançamento v1 e v2 premium, origem, agências parceiras, história (ver `reels/`).
